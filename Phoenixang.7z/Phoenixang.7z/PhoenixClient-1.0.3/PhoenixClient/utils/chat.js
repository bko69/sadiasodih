export function chat(client, message) {
	client.write("chat", {
		message: JSON.stringify({ text: "§7[§6Phoenix§7] §f" + message }),
		position: 0
	});
}

export function componentToString(component) {
	let string = "";
	try {
		if (typeof component === "string") component = JSON.parse(component);
		string += component.text ?? "";
		if (Array.isArray(component.extra)) for (const extraComponent of component.extra) string += componentToString(extraComponent);
		return string;
	} catch {}
}

export function removeFormatting(message) {
	return message?.replaceAll(/§[0-9a-fk-or]/g, "");
}

export default { chat, componentToString, removeFormatting };
